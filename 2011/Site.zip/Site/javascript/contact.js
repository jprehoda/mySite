//Form Validator Init
$(document).ready(function(){
	$("#contactForm").validationEngine({promptPosition : "topLeft", validationEventTrigger: submit});
});