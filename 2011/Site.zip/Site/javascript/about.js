//Before and After Init
$(function() {
	$('#beforeAfter').beforeAfter({
		animateIntro : true,
		introDelay : 750,
		introDuration : 750,
		showFullLinks : false
	});
});